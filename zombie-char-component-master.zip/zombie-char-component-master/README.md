# Zombie Character Preview

![image](https://user-images.githubusercontent.com/1289797/38184554-1654a98c-367b-11e8-8620-655d88916c90.png)

This component is used in [CryptoZombies.io](https://cryptoZombies.io) to generate a preview of the zombie in the browser. Refer to [lesson 6](https://cryptoZombies.io/course) for more detailed information on how it can work in conjunction with a solidity dApp.

(C) All rights reserved for the images, source code is MIT license.